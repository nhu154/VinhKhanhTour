const API = 'http://localhost:3000/api';
if(localStorage.getItem('login') !== 'true'){
  window.location.href = 'login.html';
}
function logout(){
  localStorage.removeItem('login');
  window.location.href = 'login.html';
}
// ===== LOAD POI =====
async function loadPOI(){
 const data = await fetch(API+'/poi').then(r=>r.json());
 const box = document.getElementById('poiList');
 if(!box) return;

 box.innerHTML='';

 data.forEach(p=>{
  box.innerHTML += `
  <div class="poi-card">
    <h3>${p.name}</h3>
    <p>${p.description}</p>
    <button onclick="deletePOI(${p.id})">Xóa</button>
  </div>`;
 });
}

// ===== ADD / DELETE POI =====
async function addPOI(){
 const name = document.getElementById('poiName').value;
 const description = document.getElementById('poiDesc').value;

 await fetch(API+'/poi',{
  method:'POST',
  headers:{'Content-Type':'application/json'},
  body:JSON.stringify({name,description})
 });

 loadPOI();
}

async function deletePOI(id){
 await fetch(API+'/poi/'+id,{method:'DELETE'});
 loadPOI();
}

// ===== AUDIO =====
async function addAudio(){
 const file = document.getElementById('audioFile').files[0];
 const poi_id = document.getElementById('audioPoiId').value;

 const formData = new FormData();
 formData.append('file',file);
 formData.append('poi_id',poi_id);

 await fetch(API+'/audio',{method:'POST',body:formData});
}

// ===== TOUR =====
async function addTour(){
 const name = document.getElementById('tourName').value;

 await fetch(API+'/tour',{
  method:'POST',
  headers:{'Content-Type':'application/json'},
  body:JSON.stringify({name})
 });
}

// ===== TRANSLATION =====
async function addTranslation(){
 const content = document.getElementById('transText').value;

 await fetch(API+'/translation',{
  method:'POST',
  headers:{'Content-Type':'application/json'},
  body:JSON.stringify({content})
 });
}

// ===== MAP =====
async function initMap(){

 const map = L.map('mapView').setView([10.76, 106.66], 13);

 L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
   attribution: '© OpenStreetMap'
 }).addTo(map);

 const pois = await fetch(API+'/poi').then(r=>r.json());
 const audios = await fetch(API+'/audio').then(r=>r.json());

 pois.forEach(p=>{
  if(!p.lat || !p.lng) return;

  const marker = L.marker([p.lat, p.lng]).addTo(map);

  marker.on('click', ()=>{
    const audio = audios.find(a => a.poi_id == p.id);
    if(audio){
      const player = document.getElementById('audioPlayer');
      player.src = 'http://localhost:3000/uploads/' + audio.file_url;
      player.play();
    }
  });
 });

}
// ===== LOAD ALL =====
function loadAll(){
 loadPOI();
 async function loadDashboard(){
 const poi = await fetch(API+'/poi').then(r=>r.json());
 const audio = await fetch(API+'/audio').then(r=>r.json());
 const tour = await fetch(API+'/tour').then(r=>r.json());
 const trans = await fetch(API+'/translation').then(r=>r.json());

 document.getElementById('countPOI').innerText = poi.length;
 document.getElementById('countAudio').innerText = audio.length;
 document.getElementById('countTour').innerText = tour.length;
 document.getElementById('countTrans').innerText = trans.length;

 const ctx = document.getElementById('chart');

 new Chart(ctx,{
  type:'bar',
  data:{
    labels:['POI','Audio','Tour','Translation'],
    datasets:[{
      label:'Số lượng',
      data:[poi.length, audio.length, tour.length, trans.length]
    }]
  }
 });
}

 // chỉ load map khi mở tab
}

// ===== ONLOAD =====
window.onload = loadAll;