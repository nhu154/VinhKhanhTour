// =============================
// IMPORT
// =============================
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const multer = require('multer');

// =============================
// INIT APP
// =============================
const app = express();

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// =============================
// UPLOAD CONFIG
// =============================
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) =>
    cb(null, Date.now() + '-' + file.originalname)
});

const upload = multer({ storage });

// =============================
// DATABASE
// =============================
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', // 👉 sửa nếu có mật khẩu
  database: 'tour_db'
});

db.connect(err => {
  if (err) {
    console.error('❌ Lỗi kết nối MySQL:', err);
  } else {
    console.log('✅ Kết nối MySQL thành công');
  }
});

// =============================
// API POI
// =============================
app.get('/api/poi', (req, res) => {
  db.query('SELECT * FROM poi', (err, result) => {
    if (err) return res.status(500).send(err);
    res.json(result);
  });
});

app.post('/api/poi', (req, res) => {
  const { name, description } = req.body;

  db.query(
    'INSERT INTO poi(name, description) VALUES (?,?)',
    [name, description],
    (err) => {
      if (err) return res.status(500).send(err);
      res.send('✅ Thêm POI thành công');
    }
  );
});

app.delete('/api/poi/:id', (req, res) => {
  db.query('DELETE FROM poi WHERE id=?', [req.params.id], (err) => {
    if (err) return res.status(500).send(err);
    res.send('🗑️ Đã xóa POI');
  });
});

// =============================
// API AUDIO
// =============================
app.get('/api/audio', (req, res) => {
  db.query('SELECT * FROM audio', (err, result) => {
    if (err) return res.status(500).send(err);
    res.json(result);
  });
});

app.post('/api/audio', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).send('Không có file');

  const file = req.file.filename;

  db.query(
    'INSERT INTO audio(file_url) VALUES (?)',
    [file],
    (err) => {
      if (err) return res.status(500).send(err);
      res.send('🎵 Upload audio thành công');
    }
  );
});

// =============================
// API TOUR
// =============================
app.get('/api/tour', (req, res) => {
  db.query('SELECT * FROM tour', (err, result) => {
    if (err) return res.status(500).send(err);
    res.json(result);
  });
});

app.post('/api/tour', (req, res) => {
  const { name } = req.body;

  db.query(
    'INSERT INTO tour(name) VALUES (?)',
    [name],
    (err) => {
      if (err) return res.status(500).send(err);
      res.send('🚀 Tạo tour thành công');
    }
  );
});

// =============================
// API TRANSLATION
// =============================
app.get('/api/translation', (req, res) => {
  db.query('SELECT * FROM translation', (err, result) => {
    if (err) return res.status(500).send(err);
    res.json(result);
  });
});

app.post('/api/translation', (req, res) => {
  const { content } = req.body;

  db.query(
    'INSERT INTO translation(content) VALUES (?)',
    [content],
    (err) => {
      if (err) return res.status(500).send(err);
      res.send('🌍 Lưu bản dịch thành công');
    }
  );
});

// =============================
// START SERVER
// =============================
const PORT = 3000;

app.listen(PORT, () => {
  console.log(`🚀 Server chạy tại: http://localhost:${PORT}`);
});